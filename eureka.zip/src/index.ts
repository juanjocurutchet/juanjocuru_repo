import "./styles.css";

let intentos: number = 1;
let clave: string = "eureka";

while (intentos <= 3) {
  clave = prompt("ingrese clave");
  if (clave === "eureka") {
    console.log("La contraseña es Correcta");
    intentos = 4;
  } else if (intentos == 3) {
    console.log("Ha superado la cantidad de intentos");
  }
  intentos = intentos + 1;
}
